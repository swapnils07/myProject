package com.example.demo;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AlignController {
	
	@Autowired
	AlignRepo alignRepo;

	@RequestMapping("/")
	public String home(){
		return "demo.jsp";
	}
	
	@RequestMapping("/addAlign")
	public String addAlign(Align align){
		alignRepo.save(align);
		return "demo.jsp";
	}
	
	@RequestMapping("/getAlign")
	public ModelAndView getAlign(@RequestParam int aId){
		ModelAndView mv=new ModelAndView("showAlign.jsp");
		Align align=alignRepo.findById(aId).orElse(new Align());
		mv.addObject(align);
		return mv;
	}
	
	@RequestMapping("/getAlignByName")
	public ModelAndView getAlignByName(@RequestParam String aName){
		ModelAndView mv=new ModelAndView("showAlign.jsp");
		ArrayList<Align> alignList=(ArrayList<Align>) alignRepo.findByaName(aName);
		for(Align align:alignList)
		mv.addObject(align);
		
		return mv;
	}
	
	@RequestMapping("/getAlignByName1")
	public ModelAndView getAlignByName1(@RequestParam String aName){
		ModelAndView mv=new ModelAndView("showAlign.jsp");
		ArrayList<Align> alignList=(ArrayList<Align>) alignRepo.getAlignByName(aName);
		for(Align align:alignList)
		mv.addObject(align);
		return mv;
	}
	
	
	
}
