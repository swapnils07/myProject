package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface AlignRepo extends CrudRepository<Align,Integer> {

	List<Align> findByaName(String aName);

	@Query("from Align where aName=?1")
	public List<Align> getAlignByName(String aName);
}
