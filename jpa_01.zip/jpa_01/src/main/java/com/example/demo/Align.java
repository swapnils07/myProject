package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;


//to save and fetch record in h2 using JSP custom query
@Entity
public class Align {

	@Id
	public int aId;
	public String aName;
	
	public int getaId() {
		return aId;
	}
	public void setaId(int aId) {
		this.aId = aId;
	}
	public String getaName() {
		return aName;
	}
	public void setaName(String aName) {
		this.aName = aName;
	}
	@Override
	public String toString() {
		return "Align [aId=" + aId + ", aName=" + aName + "]";
	}
	
	
	
}
