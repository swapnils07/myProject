insert into align values (1,'Swap')
insert into align values (2,'Nala')
insert into align values (3,'Shinde')
insert into align values (4,'Swap')